﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Globalization;
using Localization;
using System.Drawing;
using System.Windows.Data;

namespace LocalizationDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitializeLanguagesMenu();
            this.codeBoundTextBlock.SetBinding(
                TextBlock.TextProperty, 
                new Binding() { Source = CultureResources.ResourceDataProviders["MainApp"], Path = new PropertyPath("LoclizedText") });

            this.codeBoundTextBlockWithArgs.SetBinding(TextBlock.TextProperty, new MultiBinding() 
            {
                Converter = StringFormatConverter.Converter,
                Bindings = 
                { 
                    new Binding() { Source = CultureResources.ResourceDataProviders["MainApp"], Path = new PropertyPath("FormattedString") },
                    new Binding() { Source = DateTime.Now.Year.ToString() }
                }
            });
        }

        private void InitializeLanguagesMenu()
        {
            this.SetSelectedLanguage(null);
            foreach (CultureInfo culture in CultureResources.AvailableCultures)
            {
                MenuItem languageMenuItem = new MenuItem()
                {
                     Name = this.EncodeCultureString(culture.IetfLanguageTag),
                    IsCheckable = true,
                    IsChecked = (culture.IetfLanguageTag == CultureResources.CurrentCulture),
                    Header = new StackPanel() { Orientation = Orientation.Horizontal },
                    FlowDirection = ((culture.TextInfo.IsRightToLeft)? System.Windows.FlowDirection.RightToLeft : System.Windows.FlowDirection.LeftToRight)
                };

                Bitmap flagImage = CultureResources.GetFlag(culture.IetfLanguageTag);
                if (flagImage != null)
                {
                    //draw the flag...
                    ((StackPanel)languageMenuItem.Header).Children.Add(new System.Windows.Controls.Image()
                    {
                        Source = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(flagImage.GetHbitmap(),
                            IntPtr.Zero, Int32Rect.Empty,
                            System.Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions()),
                        Margin = new Thickness(0, 0, 5, 0)
                    });
                }
                ((StackPanel)languageMenuItem.Header).Children.Add(new TextBlock()
                {
                    Text = culture.NativeName,
                    Margin = new Thickness(((flagImage != null) ? 0 : 21), 0, 0, 0)
                });
                languageMenuItem.Checked += new RoutedEventHandler(languageMenuItem_Checked);

                this.menuOptionsLanguage.Items.Add(languageMenuItem);
            }
        }

        private void languageMenuItem_Checked(object sender, RoutedEventArgs e)
        {
            string selectedCulture = this.DecodeCultureString(((MenuItem)e.Source).Name);
            this.SetSelectedLanguage(new CultureInfo(selectedCulture));
            foreach (MenuItem languageItem in this.menuOptionsLanguage.Items)
            {
                if (languageItem.Name.Replace("_hyphen_", "-") != selectedCulture)
                {
                    languageItem.IsChecked = false;
                }
            }
        }

        private const string EncodedHyphen = "_hyphen_";

        private string EncodeCultureString(string cultureName)
        {
            return cultureName.Replace("-", MainWindow.EncodedHyphen);
        }

        private string DecodeCultureString(string cultureName)
        {
            return cultureName.Replace(MainWindow.EncodedHyphen, "-");
        }

        private void SetSelectedLanguage(CultureInfo newCulture)
        {
            if (newCulture == null)
                CultureResources.ChangeCulture(new CultureInfo("en-US"));
            else
                CultureResources.ChangeCulture(newCulture);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(CultureResources.GetString("MainApp", "HelloWorld"));
        }   
    }
}
