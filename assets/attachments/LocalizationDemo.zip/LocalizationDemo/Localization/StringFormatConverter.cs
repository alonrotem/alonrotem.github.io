﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Data;
using System.Globalization;

namespace Localization
{
    public class StringFormatConverter : IMultiValueConverter
    {
        public object Convert(object[] values, System.Type targetType, object parameter, CultureInfo culture)
        {
            if (values.Count() == 0)
                return string.Empty;
            string str = values[0].ToString();

            if (values.Count() == 1)
                return str;

            List<object> paramsList = values.ToList();
            paramsList.RemoveAt(0);
            return string.Format(str, paramsList.ToArray());
        }

        public object[] ConvertBack(object value, System.Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new System.NotImplementedException();
        }

        public static StringFormatConverter Converter = new StringFormatConverter();
    }
}
