﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Data;
using System.Globalization;
using System.Windows;
using System.IO;
//PresentationFramework
//System.Drawing
//WindowsBase
//System.Xaml

namespace Localization
{
    public static class CultureResources
    {
        #region Properties

        /// <summary>
        /// Gets or sets the current UI culture name.
        /// </summary>
        /// <value>
        /// The current UI culture name.
        /// </value>
        public static string CurrentCulture
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the resources manifested by this assembly.
        /// </summary>
        public static Dictionary<string, object> LocalizationResources
        {
            get
            {
                if (CultureResources.localizationResources.Keys.Count == 0)
                {
                    string[] resourcesInThisAssembly = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceNames();
                    foreach (string resource in resourcesInThisAssembly)
                    {
                        string res = resource.Substring(0, resource.LastIndexOf("."));
                        string resKey = res.Substring(res.LastIndexOf(".") + 1);
                        if (!CultureResources.localizationResources.ContainsKey(res))
                        {
                            Type t = Type.GetType(res);
                            object resourceInstance = t.GetConstructor(
                                    BindingFlags.NonPublic | BindingFlags.Instance,
                                    null,
                                    Type.EmptyTypes, null)
                                        .Invoke(new object[] { });
                            CultureResources.localizationResources.Add(resKey, resourceInstance);
                        }
                    }
                }
                return localizationResources;
            }
        }

        /// <summary>
        /// Gets the object data providers associated with the resources manifested by this assembly.
        /// </summary>
        public static Dictionary<string, ObjectDataProvider> ResourceDataProviders
        {
            get
            {
                CultureResources.PopulateDataProviders();
                return resourceDataProviders;
            }
        }

        /// <summary>
        /// Gets the list of cultures valid for the resources manifested by this assembly.
        /// </summary>
        public static List<CultureInfo> AvailableCultures
        {
            get
            {
                if (availableCultures.Count == 0)
                {
                    if (localizationResources.Count > 0)
                    {
                        availableCultures.Add(new CultureInfo("en-US"));
                    }
                    string resourceFileName = Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().Location) + ".resources.dll";
                    DirectoryInfo rootDir = new DirectoryInfo(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                    availableCultures.AddRange((from culture in CultureInfo.GetCultures(CultureTypes.AllCultures)
                                                join folder in rootDir.GetDirectories() on culture.IetfLanguageTag equals folder.Name
                                                where folder.GetFiles(resourceFileName).Any()
                                                select culture));
                }
                return availableCultures;
            }
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Gets a resource by name, corresponding to one of the resources in the Localization assembly.
        /// </summary>
        /// <param name="resname">The resname.</param>
        /// <returns></returns>
        public static object GetResource(string resname)
        {
            if (LocalizationResources.ContainsKey(resname))
                return LocalizationResources[resname];
            return null;
        }

        /// <summary>
        /// Changes the UI culture.
        /// </summary>
        /// <param name="culture">The new UI culture.</param>
        public static void ChangeCulture(CultureInfo culture)
        {
            CurrentCulture = culture.Name;
            System.Threading.Thread.CurrentThread.CurrentUICulture = culture;

            for (int i = 0; i < ResourceDataProviders.Keys.Count; i++)
            {
                ObjectDataProvider prov = InstantiateDataProvider(ResourceDataProviders.ElementAt(i).Key);
                if (prov != null)
                    prov.Refresh();
            }
        }

        /// <summary>
        /// Instantiates the object data providers associated with the resources manifested by this assembly,
        /// Pupulates the the resources and data providers dictionaries,
        /// Adds all the resources to the current application resources (which is why it should be called on OnStartup of App.xaml.cs
        /// </summary>
        public static void PopulateDataProviders()
        {
            if (CultureResources.resourceDataProviders.Keys.Count == 0)
            {
                string[] resourcesInThisAssembly = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceNames();
                foreach (string resource in resourcesInThisAssembly)
                {
                    string res = resource.Substring(0, resource.LastIndexOf("."));
                    string resKey = res.Substring(res.LastIndexOf(".") + 1);
                    if (!CultureResources.resourceDataProviders.ContainsKey(res))
                    {
                        ObjectDataProvider prov = null;
                        try
                        {
                            if (Application.Current.Resources.Contains(resKey))
                                prov = (ObjectDataProvider)Application.Current.FindResource(resKey);
                            else
                            {
                                prov = new ObjectDataProvider() { ObjectInstance = Localization.CultureResources.GetResource(resKey) };
                                Application.Current.Resources.Add(resKey, prov);
                            }
                        }
                        catch
                        {
                            prov = null;
                        }
                        CultureResources.resourceDataProviders.Add(resKey, prov);
                    }
                }
            }
        }

        public static string GetString(string resourceName, string key)
        {
            string str = null;
            object resource = GetResource(resourceName);
            if (resource != null)
            {
                PropertyInfo resStr = resource.GetType().GetProperty(key);
                if (resStr != null)
                {
                    str = System.Convert.ToString(resStr.GetValue(null, null));
                }
            }
            return str;
        }

        /// <summary>
        /// Gets a 16x16 icon image of a flag by a specific culture (if stored in the currnet resources)
        /// </summary>
        /// <param name="cultureName">Name of the culture (e.g. "en-US").</param>
        /// <returns>A 16x16 icon image of a flag by a specific culture (if stored in the currnet resources).</returns>
        public static System.Drawing.Bitmap GetFlag(string cultureName)
        {
            string flagName = "Flag_" + cultureName.Replace("-", "_");
            PropertyInfo flagProperty = typeof(Localization.Resources.Flags).GetProperty(flagName);
            if (flagProperty == null)
                return null;
            else
                return (System.Drawing.Bitmap)flagProperty.GetValue(null, null);
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Instantiates a data provider associated wth a static resource 
        /// (once the provider is refreshed, the bound strings are reloaded with the current UI language).
        /// </summary>
        /// <param name="resource">The name of resource to associate with the provider.</param>
        /// <returns>The instantiated data provider.</returns>
        private static ObjectDataProvider InstantiateDataProvider(string resource)
        {
            try
            {
                if (ResourceDataProviders.ContainsKey(resource))
                {
                    if (ResourceDataProviders[resource] == null)
                        ResourceDataProviders[resource] = (ObjectDataProvider)Application.Current.FindResource(resource);
                }
            }
            catch
            {
                return null;
            }
            return ResourceDataProviders[resource];
        }

        #endregion

        #region Fields

        //These fields are used for caching inforamtion about resources, data providers and available cultures.
        private static Dictionary<string, object> localizationResources = new Dictionary<string, object>();
        private static Dictionary<string, ObjectDataProvider> resourceDataProviders = new Dictionary<string, ObjectDataProvider>();
        private static List<CultureInfo> availableCultures = new List<CultureInfo>();

        #endregion
    }
}
