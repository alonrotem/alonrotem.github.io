﻿using System;
using System.Linq;

namespace EF_41_Concept
{
class Program
{
    static void Main(string[] args)
    {
        //Check seeding:
        Console.WriteLine("{0} persons are in your database.\n", DataManager.DataContext.Persons.Count());

        //Basic CRUD operations:

        //C(reate)
        if (DataManager.DataContext.Companies.FirstOrDefault(c => c.CompanyName == "Microsoft") == null)
        {
            DataModel.Company microsoft = new DataModel.Company(Guid.NewGuid(), "Microsoft");
            DataManager.DataContext.Companies.Add(microsoft);
            DataManager.DataContext.Persons.Add(new DataModel.Person(Guid.NewGuid(), "John doe", 20, DataModel.Prefix.Dr, microsoft));
            DataManager.DataContext.Persons.Add(new DataModel.Person(Guid.NewGuid(), "Klark Kent", 30, DataModel.Prefix.Dr, microsoft));
            DataManager.DataContext.SaveChanges();
        }

        //R(ead)
        IQueryable<DataModel.Person> microsoftWorkers = DataManager.DataContext.Persons.Where(person => person.Workplace.CompanyName == "Microsoft");
        Console.WriteLine("{0} persons are working in Microsoft.\n", microsoftWorkers.Count());

        //U(pdate)
        DataModel.Person johnDoe = DataManager.DataContext.Persons.FirstOrDefault(p => p.Name == "John Doe");
        if (johnDoe != null)
        {
            johnDoe.Name = "Changed Name";
            DataManager.DataContext.SaveChanges();
        }

        //D(elete)
        DataModel.Person klark = DataManager.DataContext.Persons.FirstOrDefault(p => p.Name == "Klark Kent");
        if (klark != null)
        {
            DataManager.DataContext.Persons.Remove(klark);
            DataManager.DataContext.SaveChanges();
        }
            
        //Done.
        Console.ReadKey();
    }
}
}
