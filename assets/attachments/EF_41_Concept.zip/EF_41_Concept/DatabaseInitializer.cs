﻿using System;
using System.Data.Entity;
using EF_41_Concept.DataModel;

namespace EF_41_Concept
{
public class DatabaseInitializer : CreateDatabaseIfNotExists<PersonsContext>
{
    protected override void Seed(PersonsContext context)
    {
        Company telerik = new Company(Guid.NewGuid(), "Telerik");;
        Person alon = new Person(Guid.NewGuid(), "Alon", 38, Prefix.Mr, telerik);

        context.Companies.Add(telerik);
        context.Persons.Add(alon);

        context.SaveChanges();
    }
}
}
