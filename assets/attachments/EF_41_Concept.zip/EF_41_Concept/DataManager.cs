﻿using System.Data.Entity.Infrastructure;
using System.Data.Entity;

namespace EF_41_Concept
{
public class DataManager
{
    public static PersonsContext DataContext
    {
        get
        {
            if (DataManager.dataContext == null)
            {
                Database.DefaultConnectionFactory = new SqlCeConnectionFactory("System.Data.SqlServerCe.4.0");
                DataManager.dataContext = new PersonsContext();
                bool dbExists = DataManager.dataContext.Database.Exists();
                if (dbExists)
                {
                    //UpgradeScript();
                }
                if (!dbExists)
                {
                    Database.SetInitializer(new DatabaseInitializer());
                }
                else
                    Database.SetInitializer<PersonsContext>(null);
            }
            return DataManager.dataContext;
        }
    }
    private static PersonsContext dataContext = null;
}
}
