﻿using System.Data.Entity;
using EF_41_Concept.DataModel;

namespace EF_41_Concept
{
public class PersonsContext : DbContext
{
    public PersonsContext()
        : base(PersonsContext.ConnectionString)
    {
    }

    public DbSet<Person> Persons { get; set; }
    public DbSet<Company> Companies { get; set; }

    public static string ConnectionString
    {
        get
        {
            return @"Data Source=" + 
                System.Reflection
                    .Assembly
                    .GetExecutingAssembly()
                    .Location
                    .Substring(0, 
                        System
                        .Reflection
                        .Assembly
                        .GetExecutingAssembly()
                        .Location
                        .LastIndexOf("\\") + 1) 
                + @"\\people.sdf";
        }
    }
}
}
