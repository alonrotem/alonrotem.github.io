﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EF_41_Concept.DataModel
{
public enum Prefix 
{ 
    Mr,
    Ms,
    Mrs,
    Dr
}

public class Person
{
    public Person()
    {

    }

    public Person(Guid personId, string name, int age, Prefix pref, Company workplace)
    {
        this.PersonId = personId;
        this.Name = name;
        this.Age = age;
        this.NamePrefix = pref;
        this.Workplace = workplace;
    }

    [Key]
    public Guid PersonId { get; set; }

    public string Name { get; set; }

    public int Age { get; set; }

    //public Prefix NamePrefix { get; set; }

    public Company Workplace { get; set; }

    [Required]
    public virtual Prefix NamePrefix { get; set; }

    public virtual int NamePrefixId
    {
        get { return (int)NamePrefix; }
        set { NamePrefix = (Prefix)value; }
    }
}

public class Company
{
    public Company()
    {

    }

    public Company(Guid companyId, string companyName)
    {
        this.CompanyId = companyId;
        this.CompanyName = companyName;
    }

    [Key, Column(Order =1)]
    public Guid CompanyId { get; set; }

    [Key, Column(Order = 2)]
    public string CompanyName { get; set; }
}
}
