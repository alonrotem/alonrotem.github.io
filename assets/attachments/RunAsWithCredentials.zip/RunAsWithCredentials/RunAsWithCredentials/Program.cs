﻿using System;
using System.Reflection;
using System.IO;

namespace RunAsWithCredentials
{
    class Program
    {
        public static void Main(string[] args)
        {
            string thisAppName = Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().Location);
            
            try
            {

                //Hello there
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n{0} v0.1", thisAppName);
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("11/2011 Alon Rotem\n");

                string userName = string.Empty;
                string userPass = string.Empty;
                string userDomain = string.Empty;// System.Environment.MachineName;
                string processPathToRun = string.Empty;
                string processArgs = string.Empty;

                #region Process the arguments

                for (int i = 0; i < args.Length; i++)
                {
                    string arg = args[i].Trim();
                    if (arg.ToUpper().IndexOf("/USER:") == 0)
                    {
                        if ((arg.ToUpper() == "/USER:") && (i < args.Length - 1))
                        {
                            i++;
                            userName = (args[i].Trim().StartsWith("/")) ? "" : args[i].Trim();
                        }
                        else
                        {
                            userName = arg.Substring(arg.IndexOf(":") + 1);
                        }
                        continue;
                    }
                    if (arg.ToUpper().IndexOf("/PASS:") == 0)
                    {
                        if ((arg.ToUpper() == "/PASS:") && (i < args.Length - 1))
                        {
                            i++;
                            userPass = (args[i].Trim().StartsWith("/")) ? "" : args[i].Trim();
                        }
                        else
                        {
                            userPass = arg.Substring(arg.IndexOf(":") + 1);
                        }
                        continue;
                    }
                    if (arg.ToUpper().IndexOf("/DOMAIN:") == 0)
                    {
                        if ((arg.ToUpper() == "/DOMAIN:") && (i < args.Length - 1))
                        {
                            i++;
                            userDomain = (args[i].Trim().StartsWith("/")) ? "" : args[i].Trim();
                        }
                        else
                        {
                            userDomain = arg.Substring(arg.IndexOf(":") + 1);
                        }
                        continue;
                    }
                    if (arg.ToUpper().IndexOf("/ARGS:") == 0)
                    {
                        if ((arg.ToUpper() == "/ARGS:") && (i < args.Length - 1))
                        {
                            i++;
                            processArgs = (args[i].Trim().StartsWith("/")) ? "" : args[i].Trim();
                        }
                        else
                        {
                            processArgs = arg.Substring(arg.IndexOf(":") + 1);
                        }
                        if (!string.IsNullOrWhiteSpace(processArgs))
                        {
                            processArgs = processArgs.Replace("&quot;", "\"");
                        }
                        continue;
                    }
                    //Easter egg
                    if (arg.ToUpper().IndexOf("/NYAN") == 0)
                    {
                        ShowNyanCat();
                        Console.WriteLine("Nyan any key to terminate!");
                        Console.ReadKey();
                        return;
                    }
                    if (arg.IndexOf("/") != 0)
                    {
                        processPathToRun = arg;
                        continue;
                    }
                }

                string missingArgs = "";
                string additionalErrors = "";
                bool errorsFound = false;
                if (string.IsNullOrWhiteSpace(userName))
                {
                    missingArgs += ((missingArgs == "") ? "" : ", ") + "username";
                    errorsFound = true;
                }
                if (string.IsNullOrWhiteSpace(userPass))
                {
                    missingArgs += ((missingArgs == "") ? "" : ", ") + "password";
                    errorsFound = true;
                }
                if (string.IsNullOrWhiteSpace(processPathToRun))
                {
                    missingArgs += ((missingArgs == "") ? "" : ", ") + "executable path";
                    errorsFound = true;
                }
                else
                {
                    try
                    {
                        if (!System.IO.File.Exists(processPathToRun))
                        {
                            additionalErrors += string.Format("File not found: {0}\n", processPathToRun);
                            errorsFound = true;
                        }
                    }
                    catch (Exception e)
                    {
                        additionalErrors += string.Format("Could not open file: {0}\nException:\n{1}", processPathToRun, e.Message);
                        errorsFound = true;
                    }
                }

                #endregion

                #region Process errors and show a colourful help message

                if (errorsFound)
                {
                    //help
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Usage:");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.Write("{0} /user:", thisAppName);
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[username] ");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.Write("/pass:");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[password] ");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.Write("/domain:");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[domain name] \"[executable path]\" ");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.Write("/args:");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[command line arguments]\n\n");

                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("Hint:");
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("Double quotes \" in your executable's arguments, should be converted to \\\"");

                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n---=== FAIL ===---");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    if (!string.IsNullOrWhiteSpace(missingArgs))
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine("The following argument(s) are missing:");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine(missingArgs);
                    }
                    if (!string.IsNullOrWhiteSpace(additionalErrors))
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine("Error(s):");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine(additionalErrors);
                    }
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    return;
                }

                #endregion

                #region Execute as...

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Executing: ");
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write("\"{0}\"\n", processPathToRun);

                if (!string.IsNullOrWhiteSpace(processArgs))
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("Args: ");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.Write("{0}\n", processArgs);
                }

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("As user: ");
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write("{0}\\{1}\n\n", userDomain, userName);

                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                System.Security.SecureString ssPwd = new System.Security.SecureString();

                proc.StartInfo = new System.Diagnostics.ProcessStartInfo(processPathToRun);
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.WorkingDirectory = Path.GetDirectoryName(processPathToRun);
                proc.StartInfo.Arguments = processArgs;
                if (!string.IsNullOrWhiteSpace(userDomain))
                    proc.StartInfo.Domain = userDomain;
                proc.StartInfo.UserName = userName;

                for (int x = 0; x < userPass.Length; x++)
                {
                    ssPwd.AppendChar(userPass[x]);
                }
                proc.StartInfo.Password = ssPwd;

                proc.Start();
                Console.WriteLine("Waiting for process to terminate...");
                proc.WaitForExit();
                Console.ForegroundColor = ConsoleColor.Gray;

                #endregion
            }
            catch (Exception ex)
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error!\n{0}", ex.Message);
                Console.ResetColor();
            }
        }

        #region Easter

        private static void ShowNyanCat()
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("+      o     +              o   ");
            Console.WriteLine("  +             o     +       + ");
            Console.WriteLine("o          +                    ");
            Console.WriteLine("    o  +           +        +   ");
            Console.WriteLine("+        o     o       +       o");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("-_-_-_-_-_-_-_"); 
            Console.ForegroundColor = ConsoleColor.Magenta; 
            Console.Write(",------,"); 
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("      o   \n");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("_-_-_-_-_-_-_-"); 
            Console.ForegroundColor = ConsoleColor.Magenta; 
            Console.Write("|"); 
            Console.ForegroundColor = ConsoleColor.Gray; 
            Console.Write("   /\\_/\\         \n");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("-_-_-_-_-_-_-"); 
            Console.ForegroundColor = ConsoleColor.Gray; 
            Console.Write("~"); 
            Console.ForegroundColor = ConsoleColor.Magenta; 
            Console.Write("|__"); 
            Console.ForegroundColor = ConsoleColor.Gray; 
            Console.Write("( ^ .^)"); 
            Console.ForegroundColor = ConsoleColor.White; 
            Console.Write("  +    +\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("_-_-_-_-_-_-_-"); 
            Console.ForegroundColor = ConsoleColor.Gray; 
            Console.Write("\"\" \"\" --"); 
            Console.ForegroundColor = ConsoleColor.White; 
            Console.Write("      +   \n");
            Console.WriteLine("+      o         o   +       o  ");
            Console.WriteLine("    +          +                ");
            Console.WriteLine("o        o        o     o    +  ");
            Console.WriteLine("    o           +               ");
            Console.WriteLine("+      +     o        o       + ");
            Console.WriteLine("                                ");
            Console.WriteLine("Nyan!Nyan!Nyan!Nyan!Nyan!Nyan!Ny");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        #endregion
    }
}
