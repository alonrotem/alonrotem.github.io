﻿using System;
using System.Security.Principal;

namespace CheckCurrentUser
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, {0}.", WindowsIdentity.GetCurrent().Name);



            Console.ReadKey();
        }
    }
}
