﻿using System;

namespace TeleTris
{
    public static class MainMenu
    {
        /// <summary>
        /// Shows the main menu.
        /// </summary>
        public static void ShowMainMenu()
        {
            bool quitRequested = false;
            while (!quitRequested)
            {
                Console.Clear();
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;
                Console.CursorVisible = false;
                Console.Clear();
                int selectedOptionIndex = 0;

                Console.WriteLine("\n\n\n\n\n");
                Console.BackgroundColor = ConsoleColor.Green;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.CursorLeft = 16;
                Console.Write(" TeleTris \n\n");
                string[] mainMenuOptions = { "Play", "Set speed", "Credits", "Quit" };
                int menuTopPosition = Console.CursorTop;

                PrintMenuOptions(mainMenuOptions, 0, menuTopPosition);
                bool reloadTheWholeMenu = false;
                while (!reloadTheWholeMenu && !quitRequested)
                {
                    ConsoleKeyInfo key = Console.ReadKey();
                    switch (key.Key)
                    {
                        case ConsoleKey.Enter:
                        case ConsoleKey.Spacebar:
                            switch (selectedOptionIndex)
                            {
                                case 0:
                                    Game.Play();
                                    reloadTheWholeMenu = true;
                                    break;
                                case 1:
                                    SetSpeed();
                                    reloadTheWholeMenu = true;
                                    break;
                                case 2:
                                    Program.SplashScreen();
                                    Console.ReadKey();
                                    reloadTheWholeMenu = true;
                                    break;
                                case 3:
                                    quitRequested = true;
                                    return;
                            }
                            break;
                        case ConsoleKey.DownArrow:
                        case ConsoleKey.RightArrow:
                            selectedOptionIndex++;
                            if (selectedOptionIndex == mainMenuOptions.Length)
                                selectedOptionIndex = 0;
                            PrintMenuOptions(mainMenuOptions, selectedOptionIndex, menuTopPosition);
                            break;
                        case ConsoleKey.UpArrow:
                        case ConsoleKey.LeftArrow:
                            selectedOptionIndex--;
                            if (selectedOptionIndex == -1)
                                selectedOptionIndex = mainMenuOptions.Length - 1;
                            PrintMenuOptions(mainMenuOptions, selectedOptionIndex, menuTopPosition);
                            break;
                        case ConsoleKey.Escape:
                            quitRequested = true;
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Reprints the main menu options.
        /// </summary>
        /// <param name="options">The options to display</param>
        /// <param name="selectedOption">The currently selected option to mark.</param>
        /// <param name="top">The top position of the menu on screeen.</param>
        static void PrintMenuOptions(string[] options, int selectedOption, int top)
        {
            Console.CursorVisible = false;
            Console.CursorTop = top;
            Console.CursorLeft = 0;
            for (int option = 0; option < options.Length; option++)
            {
                if (option == selectedOption)
                {
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                }
                Console.WriteLine("{0,20}{1}", "", options[option]);
            }
        }

        /// <summary>
        /// Shows the speed setting menu.
        /// </summary>
        static void SetSpeed()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            int[] speedOptions = new int[] { 10, 50, 100, 200, 400, 800, 1000 };
            int selectedOption = 0;
            for (int opt = 0; opt < speedOptions.Length; opt++)
            {
                if (Game.Speed == speedOptions[opt])
                {
                    selectedOption = opt;
                    break;
                }
            }

            PrintSpeedOptions(speedOptions, selectedOption, 10);
            bool doneSettingTheSpeed = false;
            while (!doneSettingTheSpeed)
            {
                ConsoleKeyInfo key = Console.ReadKey();
                switch (key.Key)
                { 
                    case ConsoleKey.Enter:
                    case ConsoleKey.Spacebar:
                    case ConsoleKey.Escape:
                        Game.Speed = speedOptions[selectedOption];
                        doneSettingTheSpeed = true;
                    break;
                        
                    case ConsoleKey.DownArrow:
                    case ConsoleKey.RightArrow:
                        selectedOption++;
                        if (selectedOption == speedOptions.Length)
                            selectedOption = 0;
                        PrintSpeedOptions(speedOptions, selectedOption, 10);
                    break;

                    case ConsoleKey.UpArrow:
                    case ConsoleKey.LeftArrow:
                        selectedOption--;
                        if (selectedOption == -1)
                        selectedOption = speedOptions.Length - 1;
                        PrintSpeedOptions(speedOptions, selectedOption, 10);
                    break;
                }
            }
        }

        /// <summary>
        /// Reprints the speed setting menu options.
        /// </summary>
        /// <param name="options">The options to display.</param>
        /// <param name="selectedOption">The currently selected option to mark.</param>
        /// <param name="top">The top position of the menu on screeen.</param>
        static void PrintSpeedOptions(int[] options, int selectedOption, int top)
        {
            Console.CursorTop = top;
            Console.CursorLeft = 10;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Faster << ");
            for (int curOption = 0; curOption < options.Length; curOption++)
            {
                if (curOption == selectedOption)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("-X-");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("-I-");
                }
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(" >> Slower\n\n");
            Console.CursorLeft = 10;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Speed: {0,4}", options[selectedOption]);
        }
    }
}
