﻿using System;


namespace TeleTris
{
    public class Program
    {
        static void Main(string[] args)
        {
            //initial splash screen
            SplashScreen();
            Console.ReadKey();
            
            //then the menu takes over
            MainMenu.ShowMainMenu();
        }

        /// <summary>
        /// Shows the splash screen with credits info and the Telerik logo
        /// </summary>
        public static void SplashScreen()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.CursorVisible = false;
            Console.Clear();

            char[,] telerikLogo = new char[,] {{'\0','\0','X','\0','\0','\0','X','\0','\0','\0'},
            {'\0','X','\0','X','\0','X','\0','X','\0','\0'},
            {'X','\0','\0','\0','X','\0','\0','\0','X','\0'},
            {'\0','\0','\0','X','\0','X','\0','\0','\0','\0'},
            {'\0','\0','X','\0','\0','\0','X','\0','\0','\0'},
            {'\0','X','\0','\0','\0','\0','\0','X','\0','\0'},
            {'\0','\0','X','\0','\0','\0','X','\0','\0','\0'},
            {'\0','\0','\0','X','\0','X','\0','\0','\0','\0'},
            {'\0','\0','\0','\0','X','\0','\0','\0','\0','\0'}};
            Console.WriteLine();
            for (int i = 0; i < telerikLogo.GetLength(0); i++)
            {
                Console.Write("      ");
                for (int j = 0; j < telerikLogo.GetLength(1); j++)
                {
                    if (telerikLogo[i, j] == '\0')
                    {
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.BackgroundColor = ConsoleColor.Black;
                        Console.Write(" ");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.Write("X");
                    }
                }
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("\n\n     ");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.Green;
            Console.Write("  TeleTris  \n");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("      Alon Rotem\n    Telerik 11/2011\n\n");
        }
    }
}
