﻿using System;

namespace TeleTris
{
    /// <summary>
    /// The base abstract Tetris shape class
    /// </summary>
    public abstract class TetrisShape
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TetrisShape" /> class.
        /// Sets its colour randomly and calculates its boundaries.
        /// </summary>
        public TetrisShape()
        {
            Random r = new Random();
            this.ShapeColor = (ConsoleColor)colors[r.Next(colors.Length)];
            this.boundaries = new ShapeBoundaries();
        }

        #region Properties

        /// <summary>
        /// Gets or sets the shape outline in a 2-dimensional array
        /// </summary>
        public abstract char[,] ShapeOutline 
        { 
            get; 
            protected set; 
        }
        
        /// <summary>
        /// Gets or sets the boundaries of the shape on each side.
        /// </summary>
        public ShapeBoundaries boundaries 
        { 
            get; 
            protected set; 
        }

        #endregion

        #region Protected properties

        /// <summary>
        /// Indicating the last position where the shape was drawn
        /// </summary>
        protected int lastPositionX = -1, lastPositionY = -1;

        /// <summary>
        /// The colour of the shape
        /// </summary>
        protected ConsoleColor ShapeColor { get; set; }
        
        /// <summary>
        /// The available screen colours for Tetris shapes.
        /// </summary>
        protected int[] colors = new int[] { 9, 10, 11, 12, 13, 15 };

        #endregion

        #region Base functions

        /// <summary>
        /// Rotates the shape clockwise by manipulating the array.
        /// </summary>
        public void RotateRight()
        {
            int shapeSize = this.ShapeOutline.GetLength(0);
            char[,] RotatedShape = new char[shapeSize, shapeSize];
            for (int i = 0; i < shapeSize; i++)
            {
                for (int j = 0; j < shapeSize; j++)
                {
                    RotatedShape[(shapeSize - 1) - i, j] = ShapeOutline[j, i];
                }
            }
            this.ShapeOutline = RotatedShape;
            this.RecalculateBoundaries();
        }

        /// <summary>
        /// Prints the shape to console.
        /// </summary>
        /// <param name="left">Left coordinates.</param>
        /// <param name="top">Top coordinates.</param>
        /// <param name="rotate">Indicating whether to rotate the shape on the next drawing.</param>
        public void PrintToConsole(int left, int top, bool rotate)
        {
            //if the shape is already drwan on screen somewhere else, clear it!
            if (this.lastPositionX >= 0 && this.lastPositionY >= 0)
            {
                Console.CursorLeft = this.lastPositionX;
                Console.CursorTop = this.lastPositionY;

                for (int row = this.boundaries.top; row < this.boundaries.bottom + 1; row++)
                {
                    for (int column = this.boundaries.left; column < this.boundaries.right + 1; column++)
                    {
                        if (this.ShapeOutline[row, column] != ' ')
                        {
                            Console.BackgroundColor = ConsoleColor.Black;
                            Console.Write(' ');
                        }
                        else
                        {
                            Console.CursorLeft++;
                        }
                    }
                    Console.CursorLeft = this.lastPositionX;
                    Console.CursorTop++;
                }
            }
            this.lastPositionX = left;
            this.lastPositionY = top;
            
            //Rotate the shape if requested
            if (rotate)
                this.RotateRight();

            //Draw the shape in its new position
            Console.CursorLeft = left;
            Console.CursorTop = top;
            for (int row = this.boundaries.top; row < this.boundaries.bottom + 1; row++)
            {
                for (int column = this.boundaries.left; column < this.boundaries.right + 1; column++)
                {
                    if (this.ShapeOutline[row, column] != ' ')
                    {
                        Console.BackgroundColor = this.ShapeColor;
                        Console.ForegroundColor = this.ShapeColor;
                        Console.Write('X');
                        Console.ForegroundColor = Console.BackgroundColor;
                    }
                    else
                    {
                        Console.CursorLeft++;
                    }
                }
                Console.CursorLeft = left;
                Console.CursorTop++;
            }
            Console.ResetColor();
        }

        /// <summary>
        /// Recalculates the shape boundaries on each side.
        /// </summary>
        protected void RecalculateBoundaries()
        {
            if (this.boundaries != null)
            {
                int size = this.ShapeOutline.GetLength(0);
                boundaries.left = boundaries.top = size;
                boundaries.right = boundaries.bottom = -1;

                for (int i = 0; i < size; i++)
                {
                    for (int j = 0; j < size; j++)
                    {
                        if (this.ShapeOutline[j, i] != ' ')
                        {
                            boundaries.left = Math.Min(i, boundaries.left);
                            boundaries.top = Math.Min(j, boundaries.top);
                            boundaries.bottom = Math.Max(j, boundaries.bottom);
                            boundaries.right = Math.Max(i, boundaries.right);
                        }
                    }
                }
            }
        }

        #endregion

        /// <summary>
        /// Returns a random shape.
        /// </summary>
        public static TetrisShape GetShape()
        {
            TetrisShape shape = null;

            Random shapeRand = new Random();
            switch (shapeRand.Next(4))
            {
                case 0:
                    shape = new Shape1();
                    break;
                case 1:
                    shape = new Shape2();
                    break;
                case 2:
                    shape = new Shape3();
                    break;

                case 3:
                    shape = new Shape4();
                    break;
            }
            return shape;
        }
    }

    /// <summary>
    /// This class holds the shape boundaries in the array.
    /// </summary>
    public class ShapeBoundaries
    {
        public int top { get; set; }
        public int bottom { get; set; }
        public int left { get; set; }
        public int right { get; set; }
    }

    //  #
    //  #
    //  #
    //  #
    //  #
    public class Shape1 : TetrisShape
    {
        public Shape1()
            : base()
        {
            this.ShapeOutline = new char[,] { { ' ', ' ', '#', ' ', ' ' }, { ' ', ' ', '#', ' ', ' ' }, { ' ', ' ', '#', ' ', ' ' }, { ' ', ' ', '#', ' ', ' ' }, { ' ', ' ', '#', ' ', ' ' } };
            this.RecalculateBoundaries();
        }

        public override char[,] ShapeOutline
        {
            get;
            protected set;
        }
    }

    //   23
    //0  # 
    //1  ##
    //2  #
    //
    //
    public class Shape2 : TetrisShape
    {
        public Shape2()
            : base()
        {
            this.ShapeOutline = new char[,] { { ' ', ' ', '#', ' ', ' ' }, { ' ', ' ', '#', '#', ' ' }, { ' ', ' ', '#', ' ', ' ' }, { ' ', ' ', ' ', ' ', ' ' }, { ' ', ' ', ' ', ' ', ' ' } };
            this.RecalculateBoundaries();
        }

        public override char[,] ShapeOutline
        {
            get;
            protected set;
        }
    }

    //   23 
    //1  ##
    //2  ##
    //
    //
    public class Shape3 : TetrisShape
    {
        public Shape3()
            : base()
        {
            this.ShapeOutline = new char[,] { { ' ', ' ', ' ', ' ', ' ' }, { ' ', ' ', '#', '#', ' ' }, { ' ', ' ', '#', '#', ' ' }, { ' ', ' ', ' ', ' ', ' ' }, { ' ', ' ', ' ', ' ', ' ' } };
            this.RecalculateBoundaries();
        }

        public override char[,] ShapeOutline
        {
            get;
            protected set;
        }
    }

    //   23
    //1  #
    //2  ##
    //3   #
    //
    public class Shape4 : TetrisShape
    {
        public Shape4()
            : base()
        {
            this.ShapeOutline = new char[,] { { ' ', ' ', ' ', ' ', ' ' }, { ' ', ' ', '#', ' ', ' ' }, { ' ', ' ', '#', '#', ' ' }, { ' ', ' ', ' ', '#', ' ' }, { ' ', ' ', ' ', ' ', ' ' } };
            this.RecalculateBoundaries();
        }

        public override char[,] ShapeOutline
        {
            get;
            protected set;
        }
    }
}
