﻿using System;
using System.Threading;

namespace TeleTris
{
    public static class Game
    {
        public static char[,] SkyLine;
        public static int Speed = 200;

        public static void Play()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.CursorVisible = false;
            Console.Clear();

            //print the floor
            int floorLevel = Console.WindowHeight - 5;
            Console.CursorTop = floorLevel;
            Console.CursorLeft = 0;
            string floor = "--------------";
            SkyLine = new char[floor.Length, floorLevel];
            Console.Write(floor);

            //initialize counters/fields
            int LeftPos = 0;
            int topPosition = 0;
            bool gameOver = false;
            uint score = 0;
            MessageUser(string.Format("Score: {0,4}", score), 0, floorLevel + 1, ConsoleColor.Green);
            bool onTheWayDown;
            int originalSpeed = Game.Speed;

            while (!gameOver)
            {
                //flush the keys
                while (Console.KeyAvailable) { Console.ReadKey(true); }

                TetrisShape currentShape = TetrisShape.GetShape();

                LeftPos = 0;
                topPosition = 0;
                bool collission = false;
                onTheWayDown = false;

                bool rotate = false;
                while ((!collission) && (topPosition < floorLevel - (currentShape.boundaries.bottom - currentShape.boundaries.top)))
                {
                    if (!onTheWayDown)
                    {
                        rotate = false;
                        if (Console.KeyAvailable)
                        {
                            ConsoleKeyInfo key = Console.ReadKey();

                            //check what the user pressed:
                            
                            //go left if possible
                            if ((key.Key == ConsoleKey.LeftArrow) && (LeftPos > 0) && (Game.SkyLine[LeftPos - 1, topPosition] != 'x'))
                            {
                                LeftPos--;
                            }

                            //go right if possible
                            if ((key.Key == ConsoleKey.RightArrow) && (LeftPos + (currentShape.boundaries.right - currentShape.boundaries.left) < floor.Length - 1) && (Game.SkyLine[LeftPos + (currentShape.boundaries.right - currentShape.boundaries.left + 1), topPosition] != 'x'))
                            {
                                LeftPos++;
                            }

                            //drop the shape
                            if (key.Key == ConsoleKey.DownArrow)
                            {
                                originalSpeed = Game.Speed;
                                Game.Speed = 30;
                                onTheWayDown = true;
                            }

                            //rotate
                            if ((key.Key == ConsoleKey.Spacebar))
                            {
                                rotate = true;
                            }

                            //terminate
                            if (key.Key == ConsoleKey.Escape)
                            {
                                return;
                            }
                        }
                    }

                    //print the shape in its next position
                    currentShape.PrintToConsole(LeftPos, topPosition, rotate);

                    //check if it collides with another shape, if it hasn't hit the floor yet
                    if (topPosition < floorLevel - (currentShape.boundaries.bottom - currentShape.boundaries.top) - 1)
                    {
                        for (int row = currentShape.boundaries.top; row < currentShape.boundaries.bottom + 1 && !collission; row++)
                        {
                            for (int column = currentShape.boundaries.left; column < currentShape.boundaries.right + 1 && !collission; column++)
                            {
                                if ((currentShape.ShapeOutline[row, column] != ' '))
                                {
                                    if (Game.SkyLine[LeftPos + (column - currentShape.boundaries.left), topPosition + 1 + (row - currentShape.boundaries.top)] == 'x')
                                    {
                                        collission = true;
                                    }
                                }
                            }
                        }
                    }

                    //check if there's a collission, and the shape cannot go at all
                    if ((topPosition == 0) && (collission))
                        gameOver = true;

                    Thread.Sleep(Game.Speed);
                    topPosition++;
                }

                //the shape has reached its bottom, return to normal speed if needed.
                if (onTheWayDown)
                {
                    Game.Speed = originalSpeed;
                    onTheWayDown = false;
                }

                //update the underlying map with the new shape
                for (int row = currentShape.boundaries.top; row < currentShape.boundaries.bottom + 1; row++)
                {
                    for (int column = currentShape.boundaries.left; column < currentShape.boundaries.right + 1; column++)
                    {
                        if ((currentShape.ShapeOutline[row, column] != ' '))
                        {
                            Game.SkyLine[LeftPos + (column - currentShape.boundaries.left), topPosition + (row - currentShape.boundaries.top) - 1] = 'x';
                        }
                    }
                }

                //check for whole rows
                for (int row = 0; row < SkyLine.GetLength(1); row++)
                {
                    int wholeRowCounter = 0;
                    //left to right
                    for (int column = 0; column < SkyLine.GetLength(0); column++)
                    {
                        if (SkyLine[column, row] != '\0')
                            wholeRowCounter++;
                    }
                    //a whole row is found!
                    if (wholeRowCounter == SkyLine.GetLength(0))
                    {
                        //mark it in yellow
                        Console.CursorTop = row;
                        Console.CursorLeft = 0;
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        for (int newLineMarker = 0; newLineMarker < SkyLine.GetLength(0); newLineMarker++)
                        {
                            Console.Write('@');
                        }
                        Thread.Sleep(200);
                        score++;
                        MessageUser(string.Format("Score: {0,4}", score), 0, floorLevel + 1, ConsoleColor.Green);

                        //remove the row from the underlying map
                        for (int topLine = row - 1; topLine > 0; topLine--)
                        {
                            for (int column = 0; column < SkyLine.GetLength(0); column++)
                                SkyLine[column, topLine + 1] = SkyLine[column, topLine];
                        }

                        //reset the top row of the map
                        for (int column = 0; column < SkyLine.GetLength(0); column++)
                            SkyLine[column, 0] = '\0';

                        //reprint the portion of the map which was updated
                        for (int topRow = 0; topRow < row + 1; topRow++)
                        {
                            Console.CursorTop = topRow;
                            for (int column = 0; column < SkyLine.GetLength(0); column++)
                            {
                                Console.CursorLeft = column;

                                if (SkyLine[column, topRow] == '\0')
                                {
                                    Console.ForegroundColor = ConsoleColor.White;
                                    Console.BackgroundColor = ConsoleColor.Black;
                                    Console.Write(' ');
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Gray;
                                    Console.BackgroundColor = ConsoleColor.Gray;
                                    Console.Write(SkyLine[column, topRow]);
                                }
                            }
                        }
                        row = 0;
                    }
                }

            }
            // info---------------------------
            MessageUser(string.Format("                     ! Game Over !  Score: {0,4}               ", score), 0, floorLevel + 1, ConsoleColor.Red);
            MessageUser(string.Format("Any key to return to the manu...", score), 0, floorLevel + 2, ConsoleColor.White);
            // /info---------------------------
            Console.ReadKey();
        }

        /// <summary>
        /// Prints a message to the user.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="left">The left coordinates of the message.</param>
        /// <param name="top">The top coordinates of the message.</param>
        /// <param name="color">The color to display.</param>
        static void MessageUser(string message, int left, int top, ConsoleColor color)
        {
            int origLeft = Console.CursorLeft;
            int origTop = Console.CursorTop;

            Console.CursorLeft = left;
            Console.CursorTop = top;
            Console.ForegroundColor = color;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write(message);

            Console.CursorLeft = origLeft;
            Console.CursorTop = origTop;
        }
    }
}
